const alarms = [];
const getElement = (id) => document.getElementById(id);
const createElement = (tag) => document.createElement(tag);

class Clock {

    init() {
        setInterval(this.build, 1000);
    }

    build = () => {
        const clockEl = getElement("digital-clock");
        const dateEl = getElement("digital-date");
        const time = this.toLocaleTimeString(new Date);
        const date = this.toLocaleDateString(new Date)
        clockEl.innerHTML = time;
        dateEl.innerHTML = date;
        this.checkAlarms(time);
    }

    clearForm = () => {
        getElement("hour").value = "";
        getElement("minute").value = "";
        getElement("second").value = "";
        getElement("hour").focus();
    }

    addAlarm = () => {
        const date = new Date;
        date.setHours(getElement("hour").value);
        date.setMinutes(getElement("minute").value);
        date.setSeconds(getElement("second").value);
        alarms.push(date);

        console.log(alarms)

        this.clearForm();
        this.displayAlarms();
    }

    renderAlarm = (alarm, alarmList) => {
        const li = createElement("li");
        li.innerHTML = `Alarm Ready: ${this.toLocaleTimeString(alarm)}`;
        alarmList.appendChild(li);
    }
    /*
    Primero, la función -sort- se utiliza para ordenar el arreglo alarms de menor a mayor. 
    La función de comparación utilizada para ordenar simplemente resta el segundo elemento
    del primero (d2 - d1), lo que ordena los números en orden ascendente.
    Luego, el método -getElement- se utiliza para obtener una referencia al elemento -HTML- con 
    el atributo id "alarm-list". 
    Luego, la propiedad -innerHTML- se establece en una cadena vacía para borrar cualquier 
    contenido previo del elemento.
    Finalmente, se recorre el arreglo de alarmas y se utiliza la función -renderAlarm- para 
    mostrar cada alarma en el elemento -HTML- especificado.
    */

    displayAlarms = () => {
        alarms.sort((d1, d2) => d1 - d2);
        const alarmList = getElement("alarm-list")
        alarmList.innerHTML = "";
        for (let i = 0; i < alarms.length; i++) {
            this.renderAlarm(alarms[i], alarmList);
        }
    }

    checkAlarms = (time) => {
        for (let i = 0; i < alarms.length; i++) {
            const alarm = this.toLocaleTimeString(alarms[i]);
            if (alarm === time) {
                alarms.splice(i, 1);
                this.displayAlarms();
                alert(`Alarm to ${alarm}`);
            }
        }
    }

    toLocaleTimeString = (date) => {
        return date.toLocaleTimeString()
    }

    toLocaleDateString = (date) => {
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        return date.toLocaleDateString('en-EN', options);
    }


}

const clock = new Clock();
clock.init();