class Reloj {
    init() {
        let date = new Date;
        console.log(date.toLocaleTimeString());
    }
}
const reloj = new Reloj;
reloj.init();